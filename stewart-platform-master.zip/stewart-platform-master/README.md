# stewart-platform
Software project folder for Team 17 'Untitled.docx'. University of Waterloo mechanical engineering class of 2021.
